package stringCahin.stringCahin;

//מחלקה E (סיום השרשרת)
public class E {
public String process(String prefix) {
   return prefix + "O";
}
}
