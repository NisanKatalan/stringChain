package stringCahin.stringCahin;

public class BStub extends B {
    public  BStub() {super(null);}
	
    @Override
    public String process(String prefix) {
        return prefix + ""; // הוספה מדומה
    }
}