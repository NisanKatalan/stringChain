package stringCahin.stringCahin;

public class CStub extends C {
    public  CStub() {super(null);}
	
    @Override
    public String process(String prefix) {
        return prefix + ""; // הוספה מדומה
    }
}