package stringCahin.stringCahin;

public class EStub extends E {
    public EStub() { super(); }
    
    @Override
    public String process(String prefix) {
        return prefix + ""; // הוספה מדומה
    }
}